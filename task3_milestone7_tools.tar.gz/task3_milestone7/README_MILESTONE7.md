# Milestone 7：本机验收、文档和提交

此包不替换 M6 的任何 C++ 文件，不会改变检测参数、CMake、Git 或视频。
新增的 Python 脚本只做结果检查和文档草稿生成，识别与跟踪仍由 C++ 完成。
脚本使用 Python 3.8+ 标准库和 ffprobe，不需要 pip/conda/NumPy/Python OpenCV。

## 1. 安装本包到现有工程

把 task3_milestone7_tools.tar.gz 放到 `~/桌面/vision_training`，执行：

```bash
cd ~/桌面/vision_training
file task3_milestone7_tools.tar.gz
tar -tzf task3_milestone7_tools.tar.gz | head -15
tar -xzf task3_milestone7_tools.tar.gz
mkdir -p tools tests
cp task3_milestone7/tools/finalize_task3.py tools/finalize_task3.py
cp task3_milestone7/tests/test_finalize_task3.py tests/test_finalize_task3.py
```

只复制这两个辅助文件；不要覆盖根 CMake 或 README。

```bash
python3 --version
ffprobe -version
```

若缺少 ffprobe，Ubuntu 常用安装命令为 `sudo apt update` 后 `sudo apt install ffmpeg`。
检查安装计划，不执行系统整体升级。无需为了核验另装 Python cv2。

辅助工具自测：

```bash
python3 tests/test_finalize_task3.py
```

## 2. 最终编译和运行

等待 M6 完成；保持所有代码和参数为最终版本。不要并发写同一份结果。
在独立构建目录编译，避免旧 build 中的目标掩盖遗漏的源码列表：

```bash
cmake -S . -B build_verify
cmake --build build_verify -j4
```

不加 `--target`，检查根目录统一构建的全部任务。构建失败先处理，不继续冒充成功。
如已在该目录进行过测试，可另选一个尚未使用的目录名，但下面命令要同步。

```bash
./build_verify/task3_windmill resources/task_3.mp4 result/task3_windmill/task_3
./build_verify/task3_windmill resources/task_4.mp4 result/task3_windmill/task_4
```

每条命令成功结束后再执行下一条。程序会重写 M6 最终视频及日志，旧的 M2–M5 结果仍保留。
如 M6 已使用最终源码成功重跑并验证两段视频，可不重复处理；但必须确认源码、参数和结果是同一版本。

## 3. 核验本机文件

```bash
python3 tools/finalize_task3.py --root .
```

脚本针对两个视频检查：
- ffprobe 全帧解码，尺寸、帧数、FPS、逐帧相对播放时间戳；有二值化视频时也检查。
- tracking.csv 的 23 列 M6 格式、逐帧索引、播放时刻、当前 R 与相对坐标的一致性。
- detected 必须具备有效位置；lost/waiting 不能携带陈旧目标坐标。
- ACQUIRED/REACQUIRED/RELEASED 与连续 ID、丢失计数一致；阈值从本次 tracking_summary.md 读取。
- tracking_events.csv 与逐帧事件一致，tracking_summary.md 中统计一致。

所有检查均是文件/日志的结构条件，不是图像语义、物理身份或作业总评分。
仅有相同帧数和时间戳，不能证明图像内容未重复或未重新排序。需要人工对照原图观看。
脚本不重新执行 C++ 检测器，也不自动证明旧视频来自当前源代码；请遵守先重跑再核验。
日志格式或状态机被自行修改后，需要相应更新本辅助脚本，不能通过伪造字段让它“通过”。

运行完成后自动写入：

```text
result/task3_audit/
├── audit.md
├── audit.json
├── manifest.json
├── manual_review_windows.md
├── tracking_report.auto.md
└── README_TASK3_APPEND.auto.md
```

这些都是可重新生成的自动文件，下次运行会替换；不要在这里保存人工填写内容。
脚本不会改写 `result/task3_tracking_result.md` 或根目录 `README.md`。
返回码：0=结构检查通过；1=发现失败；2=环境、路径或调用错误。
找不到视频/摘要时不会猜数字，会返回失败。一定要等 M6 的两个运行都正常结束。

## 4. 人工复查

先完整观看两个 recognition_overlay.mp4 并对照原视频，再按 `manual_review_windows.md` 回看：
- 同时存在两个有效目标时，绿色圈是否继续跟同一实体，不只是 ID 文本没变。
- 短暂丢失后，恢复的是原目标还是另一个目标。
- 每个 RELEASED 的前后，旧目标是否真的失效，还是颜色/R/圆检测产生了漏检。
- 候选序号变化本身不能证明跟踪正确，也不是永久身份编号。

观察是失败就如实写失败；没发生某类情形写“未观察到”，不能编造典型例子。
不要把本对话的参考图和参考统计当作本地 C++ 运行结果提交。

## 5. 完善报告

结构检查通过后：

```bash
cp -i result/task3_audit/tracking_report.auto.md result/task3_tracking_result.md
nano result/task3_tracking_result.md
```

已有人工报告时 `cp -i` 会询问；输入 n 保留已有报告，再手动合并新统计。
填写所有【待人工填写】，核对描述与最终代码一致；完成后把标题中的“草稿”删除。
报告链接按放在 result/ 内计算，不能把草稿留在 audit/ 中就作为正式报告。

检查占位项：

```bash
grep -n '待人工填写\|待修复' result/task3_tracking_result.md
```

保留任务 1、2 的 README，以下代码只追加一次任务 3 章节：

```bash
if grep -qF '<!-- TASK3_M7_BEGIN -->' README.md; then
    echo '任务3章节已存在，请用 nano README.md 更新，不重复追加。'
else
    printf '\n<!-- TASK3_M7_BEGIN -->\n' >> README.md
    cat result/task3_audit/README_TASK3_APPEND.auto.md >> README.md
    printf '\n<!-- TASK3_M7_END -->\n' >> README.md
fi
```

若你已经有另外的任务 3 章节，先人工合并，不再重复追加。
最终总 README 仍需包括全工程环境、三任务命令、任务 1 分析、任务 2 说明与所有结果索引。

## 6. 清理不是删除

编辑 `.gitignore`，只追加 `docs/gitignore_append.txt` 中需要的条目。
不要全局忽略 mp4、png、result/ 或 resources/。旧调试文件保留在本地即可。
`.gitignore` 不会取消对已被 Git 跟踪文件的管理；先用 git status / git ls-files 检查。

当前普通 GitHub 仓库阻止大于 100 MiB 的单文件，50 MiB 以上可能警告。
先查看待提交视频的大小，不要等提交后才发现超限：

```bash
ls -lh result/task3_windmill/task_3/recognition_overlay.mp4
ls -lh result/task3_windmill/task_4/recognition_overlay.mp4
find resources result/task3_windmill -type f -name '*.mp4' -size +104857600c -print
```

超限文件先确定 Git LFS 或讲义允许的附件交付方式；不要用普通 Git 直接提交超限文件。
外部交付时仍保留本地结果，并在 README 说明实际获取方式；不要把不在仓库里的链接写成可访问。

## 7. 提交到已有仓库

本包不访问或修改远程仓库。确认当前目录是原仓库：

```bash
git status --short
git remote -v
git branch --show-current
```

确认 origin 指向原来的 vision_training，分支名非空。不要重复 init、创建另一个仓库或强推。
暂存前检查有没有自己之前暂存的无关变更。使用精确路径，不推荐盲目 `git add .`。
最终提交需包括所有实际使用的 C++ 源文件、头文件、测试及辅助脚本、根 CMake、README、两个结果视频和结果说明。
任务 1、2 的历史内容继续保留。提交前 `git diff --cached --stat` 和 `git diff --cached --name-status` 核对。

推送后到网页确认最新 commit、文件和报告链接，再按讲义要求提交 GitHub 链接。
讲义第 25 页给出的邮箱是 1942896934@qq.com；视频过大上传失败时允许邮件附件，但还需满足实际邮件服务附件限制。
本包不会发送邮件。

## 来源与边界

课程要求：《第二次培训(2).pdf》第 22–25 页。
实现规则：先前 Milestone 6 的源码与真实日志格式。本包不改变这些规则。
工具接口参考：FFmpeg ffprobe 官方文档、CMake、Git、GitHub 官方文档（见 sources.md）。
实测范围见 TEST_REPORT.md。
