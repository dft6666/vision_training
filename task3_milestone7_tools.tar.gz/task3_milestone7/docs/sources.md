# 来源

课程依据：用户上传《第二次培训(2).pdf》第 22–25 页（任务 3、统一工程和提交要求）。
实现依据：本对话 Milestone 6 的 main.cpp、tracker.hpp、tracker.cpp；本包不替代原算法。
以下公共资料只用于工具命令、版本兼容和上传限制，不用于改写课程要求。

- FFmpeg ffprobe：https://ffmpeg.org/ffprobe.html
- CMake 命令：https://cmake.org/cmake/help/latest/manual/cmake.1.html
- Git ignore：https://git-scm.com/docs/gitignore
- Git add：https://git-scm.com/docs/git-add
- Git commit：https://git-scm.com/docs/git-commit
- Git push：https://git-scm.com/docs/git-push
- GitHub 大文件限制：https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github
- GitHub Git LFS：https://docs.github.com/en/repositories/working-with-files/managing-large-files/configuring-git-large-file-storage

检索日期：2026-09-25。平台限制可能变化；学校提交要求以用户提供讲义为依据。
